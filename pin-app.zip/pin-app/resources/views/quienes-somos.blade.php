@extends('layout')
@section('title', 'Quienes Somos')
@section('contenido')
<div class="row my-5">
    <h1>
        Quienes Somos
    </h1>
    <p>Vendemos cosas</p>
</div>
@endsection