@component('mail::message')
# {{ $mensaje->nombre }} le ha mandado un mensaje a la pagina

## Email: {{ $mensaje->email}}<br>
## Phone: {{ $mensaje ->phone}}

El mensaje era:

{{ $mensaje->message }}


{{-- @component('mail::button', ['url' => ''])
Button Text
@endcomponent --}}

Gracias,<br>
{{-- {{ config('app.name') }} --}}
@endcomponent
