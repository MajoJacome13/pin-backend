@extends('layout')
@section('title', 'Home del Sitio')
@section('contenido')
<div class="row my-5">
    <h1>
        Home
    </h1>
    <p>Esta es nuestra pagina principal</p>
</div>
@endsection