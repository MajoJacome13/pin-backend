<?php

namespace App\Http\Controllers;

use App\Models\PinContacto;
use Illuminate\Http\Request;

class PinContactoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PinContacto  $pinContacto
     * @return \Illuminate\Http\Response
     */
    public function show(PinContacto $pinContacto)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PinContacto  $pinContacto
     * @return \Illuminate\Http\Response
     */
    public function edit(PinContacto $pinContacto)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PinContacto  $pinContacto
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PinContacto $pinContacto)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PinContacto  $pinContacto
     * @return \Illuminate\Http\Response
     */
    public function destroy(PinContacto $pinContacto)
    {
        //
    }
}
