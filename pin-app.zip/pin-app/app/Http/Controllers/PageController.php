<?php

namespace App\Http\Controllers;

use App\Models\Mensaje;
use Illuminate\Http\Request;
use App\Mail\MensajeContacto;
use Illuminate\Support\Facades\Mail;

class PageController extends Controller
{
    public function home(){
        return view('home');
    }

    public function quienesSomos(){
        return view('quienes-somos');
    }

    public function contacto(){
        return view('contacto');
    }

    public function storeMensaje(){
        // return view('contacto');
        $mensaje = Mensaje::create([
            'nombre' => request()->nombre,
            'email' => request()->email,
            'phone' => request()->phone,
            'message' => request()->message
        ]);
        // dd($mensaje);

        Mail::to('maria.jose.jacome.moreira@gmail.com')->send(new MensajeContacto($mensaje));
        return redirect('/contacto')->with ('status', 'Se envio tu mensaje!');
    }

    public function storeMensajes(Request $request){
        // return view('contacto');
        
        $mensaje = Mensaje::create([
            'nombre' => $request->nombre,
            'email' => $request->email,
            'phone' => $request->phone,
            'message' => $request->message
        ]);
        // dd($mensaje);

        Mail::to('maria.jose.jacome.moreira@gmail.com')->send(new MensajeContacto($mensaje));
        // Mail::to($request->email)->send(new MensajeContacto($mensaje));
        return response()->json(array('estado' => true, 'mensaje' => $mensaje), 200);
        // return redirect('/contacto')->with ('status', 'Se envio tu mensaje!');
    }
}

