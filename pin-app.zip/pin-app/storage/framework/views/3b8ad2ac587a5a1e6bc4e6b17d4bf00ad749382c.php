<?php $__env->startSection('title', 'Quienes Somos'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="row my-5">
    <h1>
        Quienes Somos
    </h1>
    <p>Vendemos cosas</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/majojacome/Documents/Full Stack 2105/PIN/pin-app/resources/views/quienes-somos.blade.php ENDPATH**/ ?>