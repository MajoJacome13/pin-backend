<?php $__env->startSection('title', 'Contacto'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="row my-5">
    <h1>
        Contacto
    </h1>
    <p>Esta es nuestra Pagina de Contacto</p>
    <?php if(session('status')): ?>
    <div class='alert alert-sucess'>
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <form action="/contacto" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="nombre" placeholder="ingrese un nombre" name="nombre" />
        </div>
        <div class="mb-3">
            <label for="email" class="form-label"> Email </label>
            <input type="text" class="form-control" id="email" placeholder="ingrese un email" name="email" />
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label"> Phone </label>
            <input type="text" class="form-control" id="phone" placeholder="ingrese un phone" name="phone" />
        </div>
        <div class="mb-3">
            <label for="message" class="form-label">Message</label>
            <textarea type="text" class="form-control" id="message" placeholder="ingrese un message" name="message"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Enviar Mensaje</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/majojacome/Documents/Full Stack 2105/PIN/pin-app/resources/views/contacto.blade.php ENDPATH**/ ?>