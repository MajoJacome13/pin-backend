<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($mensaje->nombre); ?> le ha mandado un mensaje a la pagina

## Email: <?php echo e($mensaje->email); ?><br>
## Phone: <?php echo e($mensaje ->phone); ?>


El mensaje era:

<?php echo e($mensaje->message); ?>





Gracias,<br>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/majojacome/Documents/Full Stack 2105/PIN/pin-app/resources/views/mensaje.blade.php ENDPATH**/ ?>