<?php $__env->startSection('title', 'Home del Sitio'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="row my-5">
    <h1>
        Home
    </h1>
    <p>Esta es nuestra pagina principal</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/majojacome/Documents/Full Stack 2105/PIN/pin-app/resources/views/home.blade.php ENDPATH**/ ?>