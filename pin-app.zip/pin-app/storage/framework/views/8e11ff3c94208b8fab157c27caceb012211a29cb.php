<?php echo e($slot); ?>

<?php /**PATH /Users/majojacome/Documents/Full Stack 2105/PIN/pin-app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>