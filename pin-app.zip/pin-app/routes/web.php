<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;

// Otra forma de hacer Rutas
// Route::get('/', 'App\Http\Controllers\PageController@home');

Route::get('/', [PageController::class,'home']);
Route::get('/quienes-somos', [PageController::class,'quienesSomos']);
Route::get('/contacto', [PageController::class,'contacto']);
Route::post('/contacto', [PageController::class,'storeMensaje']);